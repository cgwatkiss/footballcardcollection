# FC 27 Card Clash

A browser-based, offline-ready men's football trading card game prototype.

## Run locally
Open `index.html` in a modern browser. No server or build tools are required.

## Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `README.md`, and `fc27-player-template.csv`.
3. In the repository, open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site.

## Game features
- Pack opening (Bronze, Gold and Elite)
- Player collection with rarity tiers
- Squad builder and auto-pick best XI
- Generated squad battles with coin rewards
- Sell duplicate cards for coins
- Import/export player database as CSV
- Local save using browser localStorage

## Importing the full official player list
The project starts with a small demo roster so the game works immediately. Those demo entries are examples and are **not a verified complete FC 27 ratings export**.

To add the full men's database, obtain a permitted CSV export from an authoritative source and import it using the **Database** tab. Required columns:

`name,club,nation,position,overall,pace,shooting,passing,dribbling,defending,physical`

Aliases such as `ovr`, `pac`, `sho`, `pas`, `dri`, `def`, and `phy` are also accepted. Missing attribute values can be left blank. Importing the same player and club again updates that record.

## Notes
- Progress is saved in the current browser on the current device. It is not automatically synced between devices.
- This is an unofficial fan-made project, not affiliated with EA SPORTS or Electronic Arts.
- Player names, logos, photos, and ratings may be protected by their respective owners. Use data and assets only where you have permission.
